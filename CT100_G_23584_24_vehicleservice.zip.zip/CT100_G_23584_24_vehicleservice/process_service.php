<?php
// Task 6: PHP Form Processing

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    header("Location: service.html");
    exit();
}

// 1. Retrieve Form Inputs using $_POST
$customerName    = isset($_POST['customerName']) ? trim($_POST['customerName']) : '';
$phone           = isset($_POST['phone']) ? trim($_POST['phone']) : '';
$email           = isset($_POST['email']) ? trim($_POST['email']) : '';
$regNumber       = isset($_POST['regNumber']) ? trim($_POST['regNumber']) : '';
$vehicleType     = isset($_POST['vehicleType']) ? trim($_POST['vehicleType']) : '';
$vehicleModel    = isset($_POST['vehicleModel']) ? trim($_POST['vehicleModel']) : 'N/A';
$manufactureYear = isset($_POST['manufactureYear']) ? intval($_POST['manufactureYear']) : 0;
$serviceDate     = isset($_POST['serviceDate']) ? trim($_POST['serviceDate']) : '';
$selectedServices = isset($_POST['services']) ? (array)$_POST['services'] : [];

// 2. Server-Side Validation
$errors = [];

if (empty($customerName)) {
    $errors[] = "Customer name is required.";
}
if (!preg_match('/^\d{10}$/', $phone)) {
    $errors[] = "Phone number must be exactly 10 digits.";
}
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    $errors[] = "Invalid email address format.";
}
if (empty($regNumber)) {
    $errors[] = "Vehicle registration number is required.";
}
if ($manufactureYear < 1980 || $manufactureYear > 2026) {
    $errors[] = "Year of manufacture must be realistic.";
}
if (empty($selectedServices)) {
    $errors[] = "At least one service must be selected.";
}

if (!empty($errors)) {
    echo "<!DOCTYPE html><html><head><link rel='stylesheet' href='css/style.css'></head><body>";
    echo "<div class='container'><h2>Submission Errors</h2><ul style='color:red;'>";
    foreach ($errors as $err) {
        echo "<li>" . htmlspecialchars($err) . "</li>";
    }
    echo "</ul><br><a href='javascript:history.back()'>Go Back</a></div></body></html>";
    exit();
}

// 3. Server-Side Independent Price Verification
$serviceCatalog = [
    "Engine Oil Change"   => 3000,
    "Brake Inspection"    => 2000,
    "Wheel Alignment"     => 2500,
    "Computer Diagnosis"  => 3500,
    "Full Service"        => 8000,
    "Tyre Balancing"      => 2000   // Note 1 Digit 4 Individualization Requirement
];

$totalCost = 0;
$verifiedServices = [];

foreach ($selectedServices as $serviceName) {
    if (array_key_exists($serviceName, $serviceCatalog)) {
        $verifiedServices[$serviceName] = $serviceCatalog[$serviceName];
        $totalCost += $serviceCatalog[$serviceName];
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Service Booking Confirmation</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <header>
        <h1>AutoCare Garage & Maintenance</h1>
    </header>

    <nav>
        <a href="index.html">Home</a>
        <a href="service.html">Book Service</a>
    </nav>

    <div class="container">
        <!-- Task 6 Confirmation Display -->
        <div class="confirmation-card">
            <h2>SERVICE REQUEST RECEIVED</h2>
            <hr><br>
            <p><strong>Customer:</strong> <?php echo htmlspecialchars($customerName); ?></p>
            <p><strong>Phone:</strong> <?php echo htmlspecialchars($phone); ?></p>
            <p><strong>Email:</strong> <?php echo htmlspecialchars($email); ?></p>
            <p><strong>Vehicle Reg:</strong> <?php echo htmlspecialchars($regNumber); ?></p>
            <p><strong>Vehicle Type:</strong> <?php echo htmlspecialchars($vehicleType); ?></p>
            <p><strong>Model & Year:</strong> <?php echo htmlspecialchars($vehicleModel); ?> (<?php echo $manufactureYear; ?>)</p>
            <p><strong>Preferred Service Date:</strong> <?php echo htmlspecialchars($serviceDate); ?></p>
            
            <br>
            <p><strong>Selected Services:</strong></p>
            <ul class="service-list">
                <?php foreach ($verifiedServices as $name => $cost): ?>
                    <li><?php echo htmlspecialchars($name); ?> - KSh <?php echo number_format($cost); ?></li>
                <?php endforeach; ?>
            </ul>

            <div style="background: #ffffff; padding: 12px; border: 1px dashed #276749; border-radius: 4px;">
                <h3 style="color: #1a365d;">ESTIMATED SERVICE COST: KSh <?php echo number_format($totalCost); ?></h3>
            </div>
            <br>
            <p>Thank you for choosing <strong>AutoCare Garage</strong>. Our service team will contact you shortly.</p>
        </div>
    </div>
</body>
</html>