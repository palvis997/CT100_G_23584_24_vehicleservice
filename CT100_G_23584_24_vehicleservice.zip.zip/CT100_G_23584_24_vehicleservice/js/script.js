/ Task 5: User-Defined Functions & Event Handlers

// Service Prices Map
const SERVICE_PRICES = {
    "Engine Oil Change": 3000,     // Task 1
    "Brake Inspection": 2000,      // Task 1
    "Wheel Alignment": 2500,       // Task 1
    "Computer Diagnosis": 3500,    // Task 1
    "Full Service": 8000,          // Task 1
    "Tyre Balancing": 2000         // Note 1 Digit 4 Individualization Requirement
};

// Function 1: Dynamic Vehicle Type Handler (Task 3 & 5)
function checkVehicleType() {
    const vType = document.getElementById('vehicleType').value;
    const infoBox = document.getElementById('vehicleTypeInfo');
    infoBox.innerText = Selected Type: ${vType} - Heavy duty checks apply for Pickup/Van models.;
}

// Function 2: Dynamic Age Warning Handler (Task 3 & 5)
function checkVehicleAge() {
    const year = parseInt(document.getElementById('manufactureYear').value) || 2026;
    const currentYear = 2026;
    const ageWarning = document.getElementById('ageWarning');

    if ((currentYear - year) >= 10) {
        ageWarning.style.display = 'block';
    } else {
        ageWarning.style.display = 'none';
    }
}

// Function 3: Service Cost Calculator (Task 4 & 5)
function calculateServiceCost() {
    const checkboxes = document.querySelectorAll('input[name="services[]"]:checked');
    let total = 0;
    let selectedNames = [];

    checkboxes.forEach(cb => {
        total += SERVICE_PRICES[cb.value] || 0;
        selectedNames.push(cb.value);
    });

    // Dynamic Updates (Task 3)
    document.getElementById('serviceSummary').innerText = 
        Services Selected (${selectedNames.length}): ${selectedNames.join(', ') || 'None'};
    
    document.getElementById('totalCostDisplay').innerText = total.toLocaleString();
    
    if (selectedNames.length > 0) {
        document.getElementById('servicesErr').style.display = 'none';
    }
}

// Real-time Input Validator for Individual Fields
function validateInput(fieldId) {
    const val = document.getElementById(fieldId).value.trim();
    const errElem = document.getElementById(fieldId + 'Err');

    if (fieldId === 'customerName' || fieldId === 'regNumber') {
        errElem.style.display = (val === '') ? 'block' : 'none';
    } else if (fieldId === 'email') {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        errElem.style.display = (!emailRegex.test(val)) ? 'block' : 'none';
    } else if (fieldId === 'phone') {
        const phoneRegex = /^\d{10}$/;
        errElem.style.display = (!phoneRegex.test(val)) ? 'block' : 'none';
    } else if (fieldId === 'manufactureYear') {
        const y = parseInt(val);
        errElem.style.display = (isNaN(y) || y < 1980 || y > 2026) ? 'block' : 'none';
    }
}

// Function 4: Master Form Validator (Task 2 & 5)
function validateServiceForm(event) {
    let isValid = true;

    // Validate Customer Name
    const customerName = document.getElementById('customerName').value.trim();
    if (customerName === '') {
        document.getElementById('customerNameErr').style.display = 'block';
        isValid = false;
    }

    // Validate Phone Number (Exactly 10 digits)
    const phone = document.getElementById('phone').value.trim();
    const phoneRegex = /^\d{10}$/;
    if (!phoneRegex.test(phone)) {
        document.getElementById('phoneErr').style.display = 'block';
        isValid = false;
    }

    // Validate Email Address
    const email = document.getElementById('email').value.trim();
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
        document.getElementById('emailErr').style.display = 'block';
        isValid = false;
    }

    // Validate Vehicle Registration Number
    const regNumber = document.getElementById('regNumber').value.trim();
    if (regNumber === '') {
        document.getElementById('regNumberErr').style.display = 'block';
        isValid = false;
    }

    // Validate Manufacture Year
    const year = parseInt(document.getElementById('manufactureYear').value);
    if (isNaN(year) || year < 1980 || year > 2026) {
        document.getElementById('manufactureYearErr').style.display = 'block';
        isValid = false;
    }

    // Validate at least one service selected
    const selectedServices = document.querySelectorAll('input[name="services[]"]:checked');
    if (selectedServices.length === 0) {
        document.getElementById('servicesErr').style.display = 'block';
        isValid = false;
    }

    if (!isValid) {
        event.preventDefault(); // Stop submission if invalid
        return false;
    }
    return true;
}

// On page load initialization
window.onload = function() {
    checkVehicleType();
    checkVehicleAge();
    calculateServiceCost();
};